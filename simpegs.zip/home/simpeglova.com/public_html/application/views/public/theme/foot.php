  {js}
  <script src="{url}"></script>
  {/js}

</body>

</html>
