
      </div>
      <!-- End of Main Content -->

<!-- MODAL -->
<!-- Button trigger modal -->



 <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; SIMPEG CV.LOVA 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="<?= base_url("public/home/logout") ?>">Logout</a>
        </div>
      </div>
    </div>
  </div>
  {js}
  <script src="{url}"></script>
  {/js}
  <script type="text/javascript">
    $(document).ready(function() {
      var date = new Date("<?= date("Y-m-d",strtotime("-19 years")) ?>");
      var currentMonth = date.getMonth();
      var currentDate = date.getDate();
      var currentYear = date.getFullYear();
      $(".dateTgl").datepicker({
        format:"yyyy-m-d",
        autoclose: true,
        todayHighlight: true,
        endDate:new Date(currentYear, currentMonth, currentDate)
      });
      $(".date").datepicker({
        format:"yyyy-m-d",
      });
      $(".datatables").DataTable({

      });
      $(".select2").select2();
      $(".datatables_pinjam").DataTable({
        "order": [[ 4, "asc" ],[ 3, "desc" ]]
      });
      $('.time').timepicker({
          minuteStep: 1,
          template: 'dropdown',
          appendWidgetTo: 'body',
          showSeconds: false,
          showMeridian: false,
          defaultTime: false,
          icons:{
            up: 'fa fa-caret-up',
            down: 'fa fa-caret-down'
        }
      });
      if ($(".datatables_absensi").length > 0) {
        var x = $(".datatables_absensi").DataTable({
          ajax:"<?= base_url("api/read") ?>",
          "order": [[ 2, "desc" ]]
        });
        setInterval(function () {
          console.log("Reload");
          x.ajax.reload();
        }, 2000);
      }

    });
  </script>

</body>

</html>
