<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @author Indra Gunanda
 */
class Absensi extends CI_Controller{
  /**
 	 * Konstruktor
 	 *
 	 * @return void
	 */

  public function __construct()
  {
    parent::__construct();
    $this->load->model("crud/main");
    if ($this->session->level != "admin") {
      redirect(base_url("public"));
    }
  }
  /**
 	 * Index Home
 	 *
 	 * @return void
	 */

  public function index()
  {
    $this->template->setFolder("admin");
    $this->template->defaultStyle("front");
    $this->main->setTable("users");
    $get = $this->main->get(["status"=>"aktif","level"=>"karyawan"]);
    $build = [
      "block_title"=>"Monitoring Absensi Pegawai",
      "data_users"=>$get->result_array()
    ];
    $this->template->renderHTML(['head','absensi','foot'],['title'=>"Monitoring Absensi Pegawai",'other'=>$build]);
  }
  public function detail($id="")
  {
    $start = $this->input->get("start");
    $end = $this->input->get("end");
    $this->template->setFolder("admin");
    $this->template->defaultStyle("front");
    $this->main->setJoin([
      "table"=>"users",
      "join"=>[
        "absensi|absensi.nip = users.nip|null"
      ]
    ]);
    $get = $this->main->get(["users.nip"=>$id]);
    if (!isset($get->row()->nama)) {
      redirect($_SERVER["HTTP_REFERER"]);
    }
    $build = [
      "block_title"=>"Detail Absensi NIP ".$id." - ".$get->row()->nama,
      "data_detail"=>$get->result_array(),
      "data_absensi"=>"",
    ];
    $ext = ["start"=>$start,"end"=>$end,"nip"=>$id];
    $this->template->renderHTML(['head','absensi_detail','foot'],["extend"=>$ext,'title'=>"Detail Absensi NIP ".$id,'other'=>$build]);
  }
  public function tambah()
  {
    $this->template->setFolder("admin");
    $this->template->defaultStyle("front");
    $build = [
      "block_title"=>"Tambah - Data Absen",
      "action"=>base_url("admin/absensi/create"),
      "msg"=>$this->session->flashdata("message")
    ];
    $this->main->setTable("users");
    $as = $this->main->get(["level"=>"karyawan"]);
    $ext = [
      "pegawai"=>$as->result()
    ];
    $this->template->renderHTML(['head','absensi_form','foot'],["extend"=>$ext,'title'=>"Tambah - Data Absen",'other'=>$build]);
  }
  public function create()
  {
    $this->main->setTable("users");
    $id_divisi = $this->main->get(["nip"=>$this->input->post("nip")])->row()->id_divisi;
    $waktu_kerja = $this->main->get(["nip"=>$this->input->post("nip")])->row()->waktu_kerja;
    $sip = "jam_masuk".$this->main->get(["nip"=>$this->input->post("nip")])->row()->sip;
    $this->main->setTable("divisi");
    $tgl = $this->input->post("tgl");
    $type = $this->input->post("type");
    $telat = $this->input->post("telat");
    $jam_masuk = $tgl." ".$this->main->get(["id_divisi"=>$id_divisi])->row()->{$sip};
    $jam_keluar = date("Y-m-d H:i:s",strtotime("+".$waktu_kerja." hours",strtotime($jam_masuk)));
    $data = ["nip"=>$this->input->post("nip"),"masuk"=>$jam_masuk,"keluar"=>$jam_keluar,"type"=>$type,"telat"=>$telat];
    $this->main->setTable("absensi");
    $ins = $this->main->insert($data);
    if ($ins) {
      $this->session->set_flashdata("message",'<div class="alert alert-success">Sukses Simpan Data</div>');
    }else {
      $this->session->set_flashdata("message",'<div class="alert alert-danger">Gagal Simpan Data</div>');
    }
    redirect($_SERVER['HTTP_REFERER']);
  }
}
