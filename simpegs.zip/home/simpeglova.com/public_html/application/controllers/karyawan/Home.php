<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @author Indra Gunanda
 */
class Home extends CI_Controller{
  /**
 	 * Konstruktor
 	 *
 	 * @return void
	 */

  public function __construct()
  {
    parent::__construct();
    $this->load->model("crud/main");
    if ($this->session->level != "karyawan") {
      redirect(base_url("public"));
    }
  }
  /**
 	 * Index Home
 	 *
 	 * @return void
	 */
  public function cetak($id)
  {
        $this->main->setJoin([
          "table"=>"penggajian",
          "join"=>[
            "users|users.nip = penggajian.nip|null",
            "divisi|divisi.id_divisi = users.id_divisi|null"
          ]
        ]);
        $row = $this->main->get(["penggajian.id_penggajian"=>$id])->row();
				$this->load->library('pdf');
        $pdf = new FPDF('l', 'mm', 'A5');
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 12);
      	$pdf->Image(base_url("assets/img/logo.png"),20,2,30);
        $pdf->Cell(190, 7, 'CV LOVA', 0, 1, 'C');
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(190, 6, 'JALAN RAYA BANJARAN KEC. Pameungpeuk', 0, 1, 'C');
        $pdf->Cell(190, 6, '0265-592324', 0, 1, 'C');
        $pdf->Line(20, 33, 210-20, 33);
        $pdf->Line(20, 34, 210-20, 34);
        $pdf->Cell(8, 8, '',0,1);
        $pdf->Cell(190, 7, 'SLIP GAJI', 0, 1, 'C');
       $pdf->SetFont('Arial', '', 12);
       $pdf->Cell(30, 6, 'Nama', 0, 0, 'l');
       $pdf->Cell(70, 6, ': '.$row->nama, 0, 0, 'l');
       $pdf->Cell(40, 6, 'NIP', 0, 0, 'l');
       $pdf->Cell(30, 6, ': '.$row->nip, 0, 1, 'l');
       $pdf->Cell(30, 6, 	'Jabatan', 0, 0, 'l');
       $pdf->Cell(70, 6, ': '.$row->nama_divisi, 0, 0, 'l');
       $pdf->Cell(40, 6, 'Pendidikan Terakhir', 0, 0, 'l');
       $pdf->Cell(30, 6, ': '.$row->pendidikan, 0, 1, 'l');
		   $pdf->Cell(8, 8, '',0,1);
	 	   $pdf->Cell(30, 6, '+(PENERIMAAN)', 0, 1, 'l');
       $pdf->Cell(30, 6, 'Gaji Pokok ', 0, 0, 'l');
       $pdf->Cell(70, 6, ': '.number_format($row->total_gaji), 0, 1, 'l');
       $tunjangan = json_decode($row->tunjangan);
       foreach ($tunjangan->tunjangan as $key => $value) {
         $pdf->Cell(30, 6, 'T '.$value->nama, 0, 0, 'l');
         $pdf->Cell(70, 6, ($value->total), 0, 1, 'l');
       }
       $pdf->Cell(30, 6, 'Uang Lembur ', 0, 0, 'l');
       $pdf->Cell(70, 6, ': '.(($tunjangan->lembur->total_lembur)."X ".number_format($tunjangan->lembur->total_bonus/$tunjangan->lembur->total_lembur)." = ".number_format($tunjangan->lembur->total_bonus)), 0, 1, 'l');
		   $pdf->Cell(30, 6, 'Gaji Akhir ', 0, 0, 'l');
       $pdf->Cell(70, 6, ': '.number_format($row->total_gaji-$row->pinalti_gaji), 0, 0, 'l');
  		 $pdf->Cell(40, 6, 'Potongan', 0, 0, 'l');
       $pdf->Cell(30, 6, ': '.number_format($row->pinalti_gaji), 0, 1, 'l');
       $pdf->Cell(120,1,'',0,0);
       $pdf->Cell(50,8,'Bandung,'.date('d/m/Y'),0,1,'C');
       $pdf->Cell(120,5,'',0,0);
       $pdf->Cell(50,5,'Direktur',0,1,'C');
       $pdf->Output();
  }
  public function index()
  {
    $this->main->setTable("setting");
    $tgl = $this->main->get(["meta_key"=>"tgl_penggajian"])->row()->meta_value;
    if (($tgl - date("d")) <= 7) {
      $sisa = ($tgl - date("d"));
      if ($sisa > 0) {
        $this->session->set_flashdata("msg","{$sisa} Hari Sebelum Hari Penggajian");
      }
    }
    $this->template->setFolder("karyawan");
    $this->template->defaultStyle("front");
    $this->main->setTable("setting");
    $tgl_gajian = $this->main->get(["meta_key"=>"tgl_penggajian"])->row()->meta_value;
    $this->main->setJoin([
      "table"=>"users",
      "join"=>[
        "divisi|divisi.id_divisi = users.id_divisi|null"
      ]
    ]);
    $data = $this->main->get(["users.level"=>"karyawan","users.status"=>"aktif","nip"=>$this->session->nip])->row();
    $build = [
      "block_title"=>"Dashboard Karyawan"
    ];
    $ext = [
      "info"=>$data,
      "tgl_gajian"=>$tgl_gajian
    ];
    $this->template->renderHTML(['head','home','foot'],["extend"=>$ext,'title'=>"Dashboard Karyawan",'other'=>$build]);
  }
}
